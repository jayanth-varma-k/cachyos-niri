#!/bin/bash

# --- CONFIGURATION ---
CONFIG="$HOME/.config/niri/config.kdl"
FPS_AC="300.000"
FPS_BATTERY="60.000"
# ---------------------

LAST_AC="-1"

while true; do
  # Check Power State
  if cat /sys/class/power_supply/AC*/online 2>/dev/null | grep -q "1"; then
    AC_STATUS=1
  else
    AC_STATUS=0
  fi

  # Only act if power state changed
  if [ "$AC_STATUS" == "$LAST_AC" ]; then
    sleep 5
    continue
  fi

  if [ "$AC_STATUS" -eq 1 ]; then
    # Plugged In: High Refresh Rate
    sed -i '/\/\/ \[INTERNAL_MONITOR_MODE\]/{n;s|.*|    mode "1920x1080@'"$FPS_AC"'"|}' "$CONFIG"
    notify-send "Power Connected" "Switching to $FPS_AC Hz" -i preferences-system-power
  else
    # Battery: Power Saving
    sed -i '/\/\/ \[INTERNAL_MONITOR_MODE\]/{n;s|.*|    mode "1920x1080@'"$FPS_BATTERY"'"|}' "$CONFIG"
    notify-send "Running on Battery" "Switching to $FPS_BATTERY Hz" -i battery-caution
  fi

  LAST_AC=$AC_STATUS
done

