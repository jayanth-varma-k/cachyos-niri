#!/bin/bash

CONFIG="$HOME/.config/niri/config.kdl"
GPU_LINE='render-drm-device "/dev/dri/renderD129"'

# Check if the line is currently commented out
if grep -q "// $GPU_LINE" "$CONFIG"; then
  # It is commented (Intel/iGPU mode) -> Switch to Nvidia
  sed -i "s|// $GPU_LINE|$GPU_LINE|" "$CONFIG"
  notify-send "GPU SET TO NVIDIA" "The session will now close. Log back in to apply." -u critical
else
  # It is active (Nvidia mode) -> Switch to Intel
  sed -i "s|$GPU_LINE|// $GPU_LINE|" "$CONFIG"
  notify-send "GPU SET TO INTEGRATED" "The session will now close. Log back in to apply." -u critical
fi

# Give the user 2 seconds to read the notification before quitting
sleep 2
niri msg action quit

